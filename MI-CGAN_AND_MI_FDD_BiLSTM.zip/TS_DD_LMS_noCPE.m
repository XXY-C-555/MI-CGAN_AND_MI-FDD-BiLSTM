function [X,Y] = TS_DD_LMS_noCPE(signal,symb_in,N,M,M2,mu0,Nswitch,plotconstel)
%% 初始化均衡器
N=N*M;
[Nt,Nm_in] = size(signal);
Lc = ceil((N-1)/2);
La = floor((N-1)/2);

% Initialize W
W = zeros(Nm_in*N,2);

for mm = 1
    W((mm-1)*N+La+1,mm) = 1;
end

for mm = 2
    W((mm-1)*N+La+1,mm) = 1;
end

%% 初始化信号和其他参数
y = signal;
m_start = ceil((Lc+1)/M);
m_end = floor((Nt-La-1)/M)-100;

xhat = zeros(m_end-m_start+1,2);
errsq = zeros(m_end-m_start+1,2);

%% 核心迭代：DD-LMS均衡 + 偏振解复用
for m = m_start:m_end

    ind = floor(m*M)-(-La:1:Lc);
    r = reshape(y(ind,:),Nm_in*N,1);

    s = W.'*r;

    if (m-m_start<Nswitch)
        xd = symb_in(m,:).';  % 训练序列
    else
        xd = QAM_Dec(s,M2);   % 直接对 s 判决，无相位补偿
    end

    err = xd - s;

    dW = conj(r)*err.';
    W = W + 2*mu0*dW;

    xhat(m-m_start+1,:) = transpose(s);
    errsq(m-m_start+1,:) = abs(err).^2;
          
end

symb=xhat(Nswitch+1:end,:);
symb_eq=symb;
X=symb_eq(:,1).';
Y=symb_eq(:,2).';

%% 作图
if(plotconstel==1) 
    figure;plot(errsq(1:end,1));
    hold on;plot(errsq(1:end,2));

    figure;
    subplot(2,1,1);
    plot(abs(W(:,1)));
    subplot(2,1,2);
    plot(abs(W(:,2)));
end
end