function [number,ratio] = BER_counter(y,x)
%     x = gen_prbs([zeros(len-1,1);1],[1 1 zeros(1,len-2)],2^len-1);
    x = [x ; x]; % if you need longer frames,you should add 0 at the end of PRBS
    x = repmat(x,[ceil(length(y)/length(x))+1 1]);
    number = 0;
    xcor = xcorr(double(x),double(y)) + xcorr(double(~x),double(~y));     %��x�ĳ�����û�й�ϵ
    number = length(y)- round(max(xcor)) + number;
    ratio = number/length(y);
end