function [Pol_X,Pol_Y]=CMMA(Pol_x_Rx,Pol_y_Rx,h,taps)%��X���ݣ�Y���ݣ�������������ͷ����
NoTaps_CMA = taps;      %Number of taps for CMMA Equalization
mu = 1e-4;    %LMS�㷨���� ���㷨���������ɵ���������С
mu_CMMA= 1e-4; %LMS�㷨���� ���㷨���������ɵ���������С
pmdTaps = NoTaps_CMA;
H_xx= zeros(pmdTaps,1);
H_xy = zeros(pmdTaps,1);
H_yx = zeros(pmdTaps,1);
H_yy = zeros(pmdTaps,1);
H_xx((pmdTaps+1)/2,1) =1;%��ͷ��ʼ�� ��ʼֱͨ��Ϊ1��������Ϊ0
H_xy((pmdTaps+1)/2,1) =0;
H_yx((pmdTaps+1)/2,1) =0;
H_yy((pmdTaps+1)/2,1) =1;

tmpLength=length(Pol_x_Rx)-NoTaps_CMA+1;
Pol_x_Rx=Pol_x_Rx-mean(Pol_x_Rx);
Pol_y_Rx=Pol_y_Rx-mean(Pol_y_Rx);
MeanPower1=mean(abs(Pol_x_Rx).^2)/10;% ���ʹ�һ��
MeanPower2=mean(abs(Pol_y_Rx).^2)/10;
Pol_x_Rx=Pol_x_Rx./sqrt(MeanPower1);
Pol_y_Rx=Pol_y_Rx./sqrt(MeanPower2);
%% Initial coefficient (CMAԤѵ��)
for iter=1:3
for i=1:h:tmpLength
        %butterfly-like CMA filter
        Pol_X_input=Pol_x_Rx(i+NoTaps_CMA-1:-1:i);
        Pol_Y_input=Pol_y_Rx(i+NoTaps_CMA-1:-1:i);
       
        Pol_X0 = H_xx.'*Pol_X_input+H_xy.'*Pol_Y_input;
        Pol_Y0 = H_yx.'*Pol_X_input+H_yy.'*Pol_Y_input;
 
        E_X = 10-abs(Pol_X0).^2;
        E_Y = 10-abs(Pol_Y0).^2;
        H_xx = H_xx+E_X*sign(Pol_X0)*conj(Pol_X_input)*mu;
        H_xy = H_xy+E_X*sign(Pol_X0)*conj(Pol_Y_input)*mu;
        H_yx = H_yx+E_Y*sign(Pol_Y0)*conj(Pol_X_input)*mu;
        H_yy = H_yy+E_Y*sign(Pol_Y0)*conj(Pol_Y_input)*mu;
end
end
%% CMMA ����
R1=sqrt(2);
R2=sqrt(10);
R3=sqrt(18);
Rf1=0.5*(R1+R2);
Rf2=0.5*(R3-R1);
Rf3=0.5*(R3-R2);
err_x=[];
err_y=[];
for iter=1:5
    for i=1:h:tmpLength  
        %butterfly-like CMA filter
        Pol_X_input=Pol_x_Rx(i+NoTaps_CMA-1:-1:i);
        Pol_Y_input=Pol_y_Rx(i+NoTaps_CMA-1:-1:i);
        ii=ceil(i/h);
        Pol_X(ii)=H_xx.'*Pol_X_input+H_xy.'*Pol_Y_input;
        Pol_Y(ii)=H_yx.'*Pol_X_input+H_yy.'*Pol_Y_input;
        epsilon_x(ii)=abs(abs(abs(Pol_X(ii))-Rf1)-Rf2)-Rf3;
        error_x(ii)=sign(abs(abs(Pol_X(ii))-Rf1)-Rf2)*sign(abs(Pol_X(ii))-Rf1)*sign(Pol_X(ii));  
        epsilon_y(ii)=abs(abs(abs(Pol_Y(ii))-Rf1)-Rf2)-Rf3;
        error_y(ii)=sign(abs(abs(Pol_Y(ii))-Rf1)-Rf2)*sign(abs(Pol_Y(ii))-Rf1)*sign(Pol_Y(ii));
       
        H_xx=H_xx-mu_CMMA*epsilon_x(ii)*error_x(ii)*conj(Pol_X_input);
        H_xy=H_xy-mu_CMMA*epsilon_x(ii)*error_x(ii)*conj(Pol_Y_input);
        H_yx=H_yx-mu_CMMA*epsilon_y(ii)*error_y(ii)*conj(Pol_X_input);
        H_yy=H_yy-mu_CMMA*epsilon_y(ii)*error_y(ii)*conj(Pol_Y_input);
        err_x=[err_x  abs(epsilon_x(ii))];
        err_y=[err_y  abs(epsilon_y(ii))];
    end 
end
figure
subplot(2,1,1);plot(err_x); %չʾ���ֵ
subplot(2,1,2);plot(err_y);
Pol_X=Pol_X.';
Pol_Y=Pol_Y.';
end