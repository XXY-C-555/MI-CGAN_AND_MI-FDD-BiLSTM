function Spectrum(E,Fs)
Npoints = length(E);
time = 1:Npoints ;
time = time./Fs*1e9;
FFT_Ex_1 = fftshift(fft(E));             %shift zero-frequency component to center of spectrum.
FFT_Ex = abs(FFT_Ex_1)./(length(E));                   
Frek = (Fs*(-(Npoints)/2:((Npoints/2)-1)))/Npoints;
figure;
plot(Frek./1e9, 10*log10(FFT_Ex.^2),'r');
title('Spectrum');
xlabel('Frequency / GHz');
ylabel('Power / dB');
% energe_p = abs(E).^2;
% energe_total = sum(abs(E).^2)
% power = energe_total/length(E)
% figure;
% plot(time, energe_p,'r');
% title('energe of the transmission signal after the Tx filter');
% xlabel('time, us');
% ylabel('Power, V');
end

