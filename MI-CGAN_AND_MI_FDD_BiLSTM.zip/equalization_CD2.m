function outdata = equalization_CD2(data_in,L,belta2,belta3,gama,Fs)
E_sig = data_in.';
N = length(E_sig);               
L=L*1e3;        
belta2 = belta2/1e27;
belta3 = belta3/1e39;   
gama = gama/1e3;
step_num = 10;          %��10�����в���
dh = L/step_num;    %dhΪ1/10���źų���
% omega = linspace(-Fs*pi,Fs*pi,length(E_sig));
dw=Fs*2*pi/N;
    omega=(-1*N/2:1:N/2-1)*dw;
    omega = fftshift(omega);
Dispersion = exp(1i*0.5*belta2*omega.^2*dh/2-1/6*belta3*omega.^3*dh/2);     %ɫɢ������λ�仯����ʽ���������⣩
% Dispersion = fftshift(Dispersion);
Nonlinear = 1i*gama*dh;         %�����Ա���ʽ
for i=1:step_num
    FFT_E_sig = fft(E_sig);     %�ź�Ƶ��
    E_sig_temp = Dispersion.*FFT_E_sig;
    E_sig_temp = ifft(E_sig_temp);
    E_sig_temp = exp(Nonlinear*abs(E_sig_temp).^2).*E_sig_temp;
    E_sig_temp = fft(E_sig_temp);
    E_sig_temp = Dispersion.*E_sig_temp;
%     E_sig = fftshift(ifft(E_sig_temp));
    E_sig = ifft(E_sig_temp);
end
outdata = E_sig;

