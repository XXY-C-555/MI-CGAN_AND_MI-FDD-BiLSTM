function Pol_X=phasecomp_16qam_VV(Pol_X,N)
j=sqrt(-1);
N=N/2;
Pol_X=Pol_X-mean(Pol_X);
Pol_X=Pol_X/sqrt(mean(abs(Pol_X).^2)/10);
X = Pol_X;
%% phase compensation
r1=sqrt(2);
r2=sqrt(10);
r3=sqrt(18);
th1=(r1+r2)/2;
th2=(r2+r3)/2;

x_prime=X; 
pre_theta_x=0;
truncated_X=zeros(length(X)-2*N,1);
tracking_theta_x=zeros(length(X)-2*N,1);
for i=N+1:length(X)-N
    x_S=abs(x_prime(i-N:i+N));%��ģ����Ϊ3����
    x_a=x_prime(i-N:i+N);
    x_1= x_a(x_S<=th1);
    x_2= x_a(x_S>th1 & x_S<th2);
    x_3= x_a(x_S>=th2);
    
    theta_ref=(sum(x_1.^4*0.2)+sum(x_3.^4*0.5))/(length(x_1)+length(x_3));%�м价�ٴη��� 
    x_21=x_2.*exp(j*(pi/4-atan(1/3)));
    x_22=x_2.*exp(-j*(pi/4-atan(1/3)));
    A=[abs(x_21.^4-theta_ref) abs(x_22.^4-theta_ref)];
    [~,index]=min(A,[],2);
    for k=1:length(x_2)
    if index(k)==1
    x_24(k)=x_21(k);
    else
    x_24(k)=x_22(k);   
    end
    end
    theta_x=angle(sum(x_1.^4*0.2)+sum(x_2.^4*0.3)+sum(x_3.^4*0.5))/4;%��Ȩƽ������λ����()

%% pi��������
    while theta_x-pre_theta_x<-pi*0.25% -2*pi*f_cap
        theta_x=theta_x+pi/2;
    end
    while theta_x-pre_theta_x>pi*0.25 %-2*pi*f_cap
        theta_x=theta_x-pi/2;
    end
    truncated_X(i-N)=X(i)*exp(-j*theta_x);%*exp(+j*1*pi/4);
    pre_theta_x=theta_x;
    tracking_theta_x(i-N)=theta_x;
end
Pol_X = truncated_X*exp(+j*1*pi/4);

figure 
plot(tracking_theta_x);title('Phase noise');