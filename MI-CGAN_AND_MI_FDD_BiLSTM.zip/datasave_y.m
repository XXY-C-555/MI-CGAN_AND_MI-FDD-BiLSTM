function [Rx_I,Rx_Q] = datasave_y(Rx_YI,Rx_YQ,namestrRx,QAM_DP_Rx_save,rseed,MI,PowerIn)
%% 参数设置
% QAM_DP_Rx_save = 1;                             %是否保存接收数据（VPI中设置）
% rseed = 20;                             %随机种子（VPI中设置）
% namestrRx = 'VPI_out';              %命名（VPI中设置）
% MI                                    %（VPI中sweep）

%% 保存y偏振数据
Rx_I = Rx_YI;
Rx_Q = Rx_YQ;
Rx_Y = Rx_YI.band.E + 1i*Rx_YQ.band.E;

% 保存地址（需更改）
pathx = ['C:\Users\XXY\Desktop\code\aE2Emodel\MI_FDD_BiLSTM\E2E_data_noFOECPE\VPI_out\Rx_Y_r',...
    num2str(rseed),'_',namestrRx,'_MI=',num2str(MI),'_100km_',num2str(PowerIn),'mW','_',num2str(length(Rx_Y)),'.mat'];

if QAM_DP_Rx_save
    save(pathx,'Rx_Y');
end

end