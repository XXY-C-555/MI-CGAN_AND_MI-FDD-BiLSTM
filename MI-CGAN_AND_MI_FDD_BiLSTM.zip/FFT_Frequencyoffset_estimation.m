function [y_Rx_to, Frequency_offset] = FFT_Frequencyoffset_estimation(y_Rx, Fs)
%% Ƶƫ�����벹���㷨

  %% Ƶƫ����
   y_Rx_4 = y_Rx .^4;
   Npoints = length(y_Rx_4);
   FFT_Ex_1 = fftshift(fft(y_Rx_4));             %shift zero-frequency component to center of spectrum.
   FFT_Ex = abs(FFT_Ex_1) ./ (Npoints );                   
   Frek = (Fs*(-(Npoints)/2:((Npoints/2)- 1)))/Npoints;
%    figure;
%    plot(Frek, 10*log10(FFT_Ex.^2),'r');
   [value, index] = max(10*log10(FFT_Ex.^2));
   Frequency_offset = (Frek(index)/4);
  if Frequency_offset==0
    FFT_Ex(index) = 0;
   [value, index] = max(10*log10(FFT_Ex.^2));
   Frequency_offset = (Frek(index)/4);
  end 
  
  if abs(Frequency_offset)>200e6
   Npoints = length(y_Rx);
   FFT_Ex_2 = fftshift(fft(y_Rx));             %shift zero-frequency component to center of spectrum.
   FFT_Ex2 = abs(FFT_Ex_2) ./ (Npoints );                   
   Frek2 = (Fs*(-(Npoints)/2:((Npoints/2)- 1)))/Npoints;
   [value, index] = max(10*log10(FFT_Ex2.^2));
   Frequency_offset = (Frek2(index));
  end
%    Frequency_offset = -4.8479e+07;
   %% Ƶƫ����
  % Frequency_offset 
   y_Rx_to = y_Rx;
   for k = 2: Npoints
    y_Rx_to(k) = y_Rx(k)*exp(-1i*2*pi*Frequency_offset*(k-1)*1/Fs);
   end
%   y_Rx_to_4=y_Rx_to .^4;
%   Npoints = length(y_Rx_to_4);
%   FFT_Ex_2 = fftshift(fft(y_Rx_to_4));             %shift zero-frequency component to center of spectrum.
%   FFT_Ex_2 = abs(FFT_Ex_2)./(Npoints );                   
%   Frek_1 = (Fs*(-(Npoints)/2:((Npoints/2)-1)))/Npoints;
%   figure;
%   plot(Frek_1, 10*log10(FFT_Ex_2.^2),'r');
end