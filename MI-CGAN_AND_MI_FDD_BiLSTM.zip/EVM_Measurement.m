function [EVM,SNR] = EVM_Measurement(QAM_order,data)
if QAM_order == 32
    QAM_order = 36;
    M = 4;
    n = 1:M;
    C_ideal_I=(2*n-1-M);
    C_ideal_Q=(2*n-1-M)';
    C_ideal = repmat(C_ideal_I,M,1)+1i*repmat(C_ideal_Q,1,M);
    L = length(data);
    Pideal_ave = 20;
    Ref_Cideal = reshape(C_ideal,1,QAM_order);
    Ref_Cideal = [Ref_Cideal(2:5),Ref_Cideal(7:30),Ref_Cideal(32:35)];
    Ref_Cideal_Mat = repmat(Ref_Cideal,L,1);
    data = reshape(data,L,1);
    data_mat = repmat(data,1,32);
    Perror_mat = min(abs(data_mat-Ref_Cideal_Mat).^2,[],2);
    EVM = sqrt(mean(Perror_mat)/Pideal_ave);
    SNR_r = 1/(EVM^2);                            %EVM��SNR�Ĺ�ϵ
    SNR = 10*log10(SNR_r);
    X=['EVM of RMS is ',num2str(EVM*100),' %'];
    Y=['SNR of the received constellation is ',num2str(SNR),' dB'];
    disp(X);
    % disp(Y);
else
    M = sqrt(QAM_order);
    n = 1:M;
    C_ideal_I=(2*n-1-M);
    C_ideal_Q=(2*n-1-M)';
    C_ideal = repmat(C_ideal_I,M,1)+1i*repmat(C_ideal_Q,1,M);
    L = length(data);
    Pideal_ave = mean(mean(C_ideal.*(C_ideal.')'));
    Ref_Cideal = reshape(C_ideal,1,QAM_order);
    Ref_Cideal_Mat = repmat(Ref_Cideal,L,1);
    data = reshape(data,L,1);
    data_mat = repmat(data,1,QAM_order);
    Perror_mat = min(abs(data_mat-Ref_Cideal_Mat).^2,[],2);
    EVM = sqrt(mean(Perror_mat)/Pideal_ave);
    SNR_r = 1/(EVM^2);                            %EVM��SNR�Ĺ�ϵ
    SNR = 10*log10(SNR_r);
    X=['EVM of RMS is ',num2str(EVM*100),' %'];
    Y=['SNR of the received constellation is ',num2str(SNR),' dB'];
    disp(X);
    % disp(Y);
end
end

