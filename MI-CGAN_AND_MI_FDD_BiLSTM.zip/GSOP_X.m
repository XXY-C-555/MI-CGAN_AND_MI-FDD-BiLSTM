function [CX]=GSOP_X(Cx)
x_I=real(Cx);
x_Q=imag(Cx);


x_PI=sum((x_I).^2)/length(x_I);
x_PQ=sum((x_Q).^2)/length(x_Q);


R_x=sum((x_I).*(x_Q))/length(x_I);


x_I_0=x_I/sqrt(x_PI);
x_Q_1=x_Q-R_x*x_I/x_PI;
x_Q_0=x_Q_1/sqrt(x_PQ);



x_PI_0=sum((x_I_0).^2)/length(x_I_0);
x_PQ_0=sum((x_Q_0).^2)/length(x_Q_0);


CX=x_I_0/sqrt(x_PI_0+x_PQ_0)+1i*x_Q_0/sqrt(x_PI_0+x_PQ_0);

end