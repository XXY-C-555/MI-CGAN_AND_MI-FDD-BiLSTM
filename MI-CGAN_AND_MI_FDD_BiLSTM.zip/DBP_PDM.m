function [x_DBP,y_DBP] = DBP_PDM(signal_x,signal_y,Nsteps,SymbolRate,N,a_x,a_y,L_span,Loops,Pin,alpha1,CD,gamma)

%% �����Լ��
X = signal_x;
Y = signal_y;

if Nsteps == 0
    for h = 1:Loops
        X = CDC(X,CD,L_span/2,SymbolRate,N);
        Y = CDC(Y,CD,L_span/2,SymbolRate,N);
        X = CDC(X,CD,L_span/2,SymbolRate,N);
        Y = CDC(Y,CD,L_span/2,SymbolRate,N);
    end
else
    L=zeros(1,Nsteps);
    for i=2:Nsteps
        dl = -real(log(1-exp(alpha1*L(i-1))/Nsteps)/alpha1);
        % exp(alpha*L(i-1))���źž�������L(i-1)��˥��������Nsteps��˥��������ÿ��
        L(i) = L(i-1) + dl;
        % L:[0,dl,dl(dl)]
    end

    for h = 1:Loops
        for k = length(L):-1:1
            % ����ÿ�γ���
            if k == Nsteps
                L2 = L_span-L(k);
                % ��һ��ʱL2ΪL_span-L(3)
            else
                L2 = L(k+1)-L(k);
                % �ڶ���ΪL(3)-L(2)
                % ������ΪL(2)
            end
    
            % ɫɢ����
            X = CDC(X,CD,L2/2,SymbolRate,N);
            Y = CDC(Y,CD,L2/2,SymbolRate,N);
    
            % �����Բ���
            P_w = Pin*exp(-alpha1*L2);
            Leff = (1-exp(-alpha1*L2))/alpha1; % ���������賤��
            NLPS_x = a_x*8/9*gamma*Leff*((abs(X).^2)./mean(abs(X).^2)+(abs(Y).^2)./mean(abs(Y).^2))*P_w;
            NLPS_y = a_y*8/9*gamma*Leff*((abs(X).^2)./mean(abs(X).^2)+(abs(Y).^2)./mean(abs(Y).^2))*P_w;
            X = X.*exp(1i*NLPS_x);
            Y = Y.*exp(1i*NLPS_y);

            % ɫɢ����
            X = CDC(X,CD,L2/2,SymbolRate,N);
            Y = CDC(Y,CD,L2/2,SymbolRate,N);
    
        end
    end
end



% if Nsteps == 0
%     for h = 1:Loops
%         X = CDC(X,CD,L_span,SymbolRate,N);
%         Y = CDC(Y,CD,L_span,SymbolRate,N);
%     end
% else
%     for h = 1:Loops
%         for i = 1:Nsteps
%             L_step = L_span/Nsteps;
%             % ɫɢ����
%             X = CDC(X,CD,L_step/2,SymbolRate,N);
%             Y = CDC(Y,CD,L_step/2,SymbolRate,N);
%     
%             % �����Բ���
%             Leff = (1-exp(-alpha*L_step))/alpha; % ���������賤��
%             NLPS_x = a_x*8/9*gamma*Leff*((abs(X).^2)./mean(abs(X).^2)+(abs(Y).^2)./mean(abs(Y).^2));
%             NLPS_y = a_y*8/9*gamma*Leff*((abs(X).^2)./mean(abs(X).^2)+(abs(Y).^2)./mean(abs(Y).^2));
%             X = X.*exp(1i*NLPS_x);
%             Y = Y.*exp(1i*NLPS_y);
% 
% %             P_w = Pin*exp(-alpha*L_step);
% %             Leff = (1-exp(-alpha*L_step))/alpha; % ���������賤��
% %             NLPS_x = a_x*8/9*P_w*gamma*Leff*((abs(X).^2)./mean(abs(X).^2)+(abs(Y).^2)./mean(abs(Y).^2));
% %             NLPS_y = a_y*8/9*P_w*gamma*Leff*((abs(X).^2)./mean(abs(X).^2)+(abs(Y).^2)./mean(abs(Y).^2));
% %             X = X.*exp(1i*NLPS_x);
% %             Y = Y.*exp(1i*NLPS_y);
% 
%             % ɫɢ����
%             X = CDC(X,CD,L_step/2,SymbolRate,N);
%             Y = CDC(Y,CD,L_step/2,SymbolRate,N);
%         end
%     end
% end



% ���ƹ�һ��
x_DBP = X;
y_DBP = Y;

end