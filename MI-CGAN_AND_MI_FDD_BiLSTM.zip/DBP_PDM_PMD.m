function [x_DBP,y_DBP] = DBP_PDM_PMD(signal_x,signal_y,Nsteps,SymbolRate,N,a_x,a_y,L_span,Loops,Pin,alpha1,CD,DGD,gamma)

%% 非线性间隔
X = signal_x;
Y = signal_y;

if Nsteps == 0
    for h = 1:Loops
        [X,Y] = CDC_PMD(X,Y,CD,DGD,L_span/2,SymbolRate,N);
        [X,Y] = CDC_PMD(X,Y,CD,DGD,L_span/2,SymbolRate,N);
    end
else
    L=zeros(1,Nsteps);
    for i=2:Nsteps
        dl = -real(log(1-exp(alpha1*L(i-1))/Nsteps)/alpha1);
        % exp(alpha*L(i-1))：信号经过距离L(i-1)的衰减，除以Nsteps将衰减分配至每步
        L(i) = L(i-1) + dl;
        % L:[0,dl,dl(dl)]
    end

    for h = 1:Loops
        for k = length(L):-1:1
            % 设置每段长度
            if k == Nsteps
                L2 = L_span-L(k);
                % 第一步时L2为L_span-L(3)
            else
                L2 = L(k+1)-L(k);
                % 第二步为L(3)-L(2)
                % 第三步为L(2)
            end
    
            % 色散补偿
            [X,Y] = CDC_PMD(X,Y,CD,DGD,L2/2,SymbolRate,N);
    
            % 非线性补偿
            P_w = Pin*exp(-alpha1*L2);
            Leff = (1-exp(-alpha1*L2))/alpha1; % 非线性所需长度
            NLPS_x = a_x*8/9*gamma*Leff*((abs(X).^2)./mean(abs(X).^2)+(abs(Y).^2)./mean(abs(Y).^2))*P_w;
            NLPS_y = a_y*8/9*gamma*Leff*((abs(X).^2)./mean(abs(X).^2)+(abs(Y).^2)./mean(abs(Y).^2))*P_w;
            X = X.*exp(1i*NLPS_x);
            Y = Y.*exp(1i*NLPS_y);

            % 色散补偿
            [X,Y] = CDC_PMD(X,Y,CD,DGD,L2/2,SymbolRate,N);
    
        end
    end
end

% 类似归一化
x_DBP = X;
y_DBP = Y;

end