 function [X,Y,PhaseError] = TS_DD_LMS(signal,symb_in,N,M,M2,mu0,Nswitch,plotconstel,Ns_PE)
%% ��ʼ��������
 N=N*M;
[Nt,Nm_in] = size(signal);
Lc = ceil((N-1)/2);
La = floor((N-1)/2);

% Initialize W
W = zeros(Nm_in*N,2);

  for mm = 1
%             W((mm-1)*N+La+2,mm) = 1;
            W((mm-1)*N+La+1,mm) = 1;
  end

  for mm = 2
%             W((mm-1)*N+La+2,mm) = 1;
            W((mm-1)*N+La+1,mm) = 1;
  end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% ��ʼ���źź���������
y = signal;
m_start = ceil((Lc+1)/M);
m_end = floor((Nt-La-1)/M)-100;
 % figure;plot(real(y));
% Initialize matrices
phi = zeros(1,2);
xhat = zeros(m_end-m_start+1,2);
errsq = zeros(m_end-m_start+1,2);
PhaseError = zeros(m_end-m_start+1,2);


%% ������λ����
for m = m_start:m_end

    ind = floor(m*M)-(-La:1:Lc);
%     ind = m:N+m-1;
    r = reshape(y(ind,:),Nm_in*N,1);

    s = W.'*r;
    s1 = s.*transpose(exp(-1i*phi));

    if (m-m_start<Nswitch)
        xd = symb_in(m,:).';  % symb_inӦ��Ҳ�Ǹ������ţ�x��y��
    else
        xd = QAM_Dec(s1,M2);  % ������Ǹ������ţ�x��y��
%         xd = QAM128_Dec(s1,M2);
    end
    
    
    for mm = 1:2
        dPE=angle(xd(mm)'*s1(mm));
        phi(mm)=phi(mm)+1/Ns_PE/2*dPE;  
    end


    s = s.*transpose(exp(-1i*phi));
    err = (xd - s).*exp(1i*phi.');

    dW = conj(r)*err.';
    W = W + 2*mu0*dW;

    xhat(m-m_start+1,:) = transpose(s);
    PhaseError(m-m_start+1,:) = phi;
    errsq(m-m_start+1,:) = abs(err).^2;
          
end

symb=xhat(Nswitch+1:end,:);
% symb=xhat(5000+1:end,:);

symb_eq=symb;
X=symb_eq(:,1).';
Y=symb_eq(:,2).';
%% ��ͼ
 if(plotconstel==1) 
    figure;plot(errsq(1:end,1));
    hold on;plot(errsq(1:end,2));

    % figure;plot(PhaseError(1:end,1));
    % hold on;plot(PhaseError(1:end,2));

    figure;
    subplot(2,1,1);
    plot(abs(W(:,1)));
    subplot(2,1,2);
    plot(abs(W(:,2)));
 end
end