%% Square QAM decision function

function Sym_dec = QAM_Dec(Sym_in,m)

[r,c]=size(Sym_in);
sym_res=reshape(Sym_in,r*c,1);
N = r*c;
% Sym_ref=[-3 -1 1 3];

Sym_ref=-(sqrt(m)-1):2:(sqrt(m)-1);

M = size(Sym_ref,2);  %����
dist_r = abs(repmat(real(sym_res),1,M)- repmat(Sym_ref,N,1));
[minval_r,minindex_r] = min(dist_r,[],2);
 
dist_i = abs(repmat(imag(sym_res),1,M)- repmat(Sym_ref,N,1));
[minval_i,minindex_i] = min(dist_i,[],2);
 
Sym_dec = transpose(Sym_ref(minindex_r)+1i*Sym_ref(minindex_i));
    
Sym_dec  =reshape(Sym_dec,r,c);

end


