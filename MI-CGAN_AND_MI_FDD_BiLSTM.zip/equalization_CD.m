function output = equalization_CD(E_sig,L_km,cp_D,Fs)

% slope = 0;
N = length(E_sig);  
    L=L_km*1e3;
    D=cp_D/1e6;
    c=3e8;
    fc=193.1e12;
    lambda= c/fc;

    dw=Fs*2*pi/N;
    omega=(-1*N/2:1:N/2-1)*dw;
    omega = fftshift(omega);
    FFT_E_sig = fft(E_sig);

    H_disp = exp(-1i*lambda^2*D*L.*omega.^2./(4*pi*c));   %���ǹ����ŵ�������inverse ������
    
    slope =  0.1e3;
    beta3 = lambda.^2/(2*pi*c).^2*(lambda.^2*slope + 2*lambda*D);
%     H_disp = exp(-1i*lambda^2*D*L.*omega.^2./(4*pi*c)+1i.*omega.^3/6*L.*beta3);   %   ��������ɫɢ
        
    H_disp = H_disp.';
    FFT_E_sig_aD = FFT_E_sig.*H_disp;
    output = ifft(FFT_E_sig_aD);
end