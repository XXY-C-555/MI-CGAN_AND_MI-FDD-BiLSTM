function [signalout_X,signalout_Y]= CDC_PMD(signal_x,signal_y,Dispersion,DGD,fiberlength,SymbolRate,N)

% 此函数的输入信号应当是行向量！！！

%% 参数
if size(signal_x,1) > size(signal_x,2)
    X = signal_x.';
else 
    X = signal_x;
end

if size(signal_y,1) > size(signal_y,2)
    Y = signal_y.';
else 
    Y = signal_y;
end


FFTsize     = N*2*256;          % FFT大小
% EffFFTsize  = N*2*175;
EffFFTsize  = N*2*175;
df          = SymbolRate/FFTsize; % 频率分辨率
f           = (-round(FFTsize/2)+1:round(FFTsize/2))*df; % 生成频率数组
Omega       = 2*pi*f;           % 角频率w

% 色散
D = Dispersion;
c = 3e8;
freq = 193.1e12;
lambda = c/freq;
Beta2 = -D*(lambda^2)/(2*pi*c);

%% 色散补偿

Hf_X = exp((1i/2)*Beta2*Omega.^2*fiberlength-(1i/2)*DGD*Omega*fiberlength); % 频域色散补偿
Hf_Y = exp((1i/2)*Beta2*Omega.^2*fiberlength+(1i/2)*DGD*Omega*fiberlength); % 频域色散补偿
% Hf = exp(-1i*lambda^2*D*fiberlength.*Omega.^2./(4*pi*c));
NBlocks=ceil(length(X)/EffFFTsize);
for j=1:NBlocks
    step  = round(FFTsize-EffFFTsize)/2; % 重叠保护区域
    position  = -(j-1)*EffFFTsize+step; % 滑动窗口步长为Efft+step

    S_X     = circshift(X,[1 position]); % 将X循环移位，以实现给每个EFFT数据块前后添加一个step块
    S_Y     = circshift(Y,[1 position]); % 将X循环移位，以实现给每个EFFT数据块前后添加一个step块

    Block_X = S_X(1:FFTsize); % 每次都取循环移位过的信号的第一个到FFTsize的部分
    Block_Y = S_Y(1:FFTsize); % 每次都取循环移位过的信号的第一个到FFTsize的部分

    ProcessedBlock_X=ifft(ifftshift(fftshift(fft(Block_X)).*Hf_X));
    ProcessedBlock_Y=ifft(ifftshift(fftshift(fft(Block_Y)).*Hf_Y));

    signal_X((j-1)*EffFFTsize+1:j*EffFFTsize)=ProcessedBlock_X(step+1:step+EffFFTsize); % 每次取Efft个数据输出
    signal_Y((j-1)*EffFFTsize+1:j*EffFFTsize)=ProcessedBlock_Y(step+1:step+EffFFTsize); % 每次取Efft个数据输出
end
signalout_X = signal_X(1:length(X));
signalout_Y = signal_Y(1:length(Y));

end


